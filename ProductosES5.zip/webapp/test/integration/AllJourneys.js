/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"cursoui5/ProductosES5/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"cursoui5/ProductosES5/test/integration/pages/Worklist",
	"cursoui5/ProductosES5/test/integration/pages/Object",
	"cursoui5/ProductosES5/test/integration/pages/NotFound",
	"cursoui5/ProductosES5/test/integration/pages/Browser",
	"cursoui5/ProductosES5/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "cursoui5.ProductosES5.view."
	});

	sap.ui.require([
		"cursoui5/ProductosES5/test/integration/WorklistJourney",
		"cursoui5/ProductosES5/test/integration/ObjectJourney",
		"cursoui5/ProductosES5/test/integration/NavigationJourney",
		"cursoui5/ProductosES5/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});