sap.ui.define([
	"test/unit/model/models",
	"test/unit/model/formatter",
	"test/unit/controller/App.controller",
	"test/unit/controller/ListSelector",
	"test/unit/model/grouper",
	"test/unit/model/GroupSortState"
], function() {
	"use strict";
});