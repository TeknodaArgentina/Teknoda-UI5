/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 SalesOrderCollection in the list
// * All 3 SalesOrderCollection have at least one SalesOrderItems

sap.ui.require([
	"sap/ui/test/Opa5",
	"cursoui5/PedidoVentas/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"cursoui5/PedidoVentas/test/integration/pages/App",
	"cursoui5/PedidoVentas/test/integration/pages/Browser",
	"cursoui5/PedidoVentas/test/integration/pages/Master",
	"cursoui5/PedidoVentas/test/integration/pages/Detail",
	"cursoui5/PedidoVentas/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "cursoui5.PedidoVentas.view."
	});

	sap.ui.require([
		"cursoui5/PedidoVentas/test/integration/MasterJourney",
		"cursoui5/PedidoVentas/test/integration/NavigationJourney",
		"cursoui5/PedidoVentas/test/integration/NotFoundJourney",
		"cursoui5/PedidoVentas/test/integration/BusyJourney"
	], function () {
		QUnit.start();
	});
});