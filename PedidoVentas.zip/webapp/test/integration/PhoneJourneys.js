/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"cursoui5/PedidoVentas/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"cursoui5/PedidoVentas/test/integration/pages/App",
	"cursoui5/PedidoVentas/test/integration/pages/Browser",
	"cursoui5/PedidoVentas/test/integration/pages/Master",
	"cursoui5/PedidoVentas/test/integration/pages/Detail",
	"cursoui5/PedidoVentas/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "cursoui5.PedidoVentas.view."
	});

	sap.ui.require([
		"cursoui5/PedidoVentas/test/integration/NavigationJourneyPhone",
		"cursoui5/PedidoVentas/test/integration/NotFoundJourneyPhone",
		"cursoui5/PedidoVentas/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});